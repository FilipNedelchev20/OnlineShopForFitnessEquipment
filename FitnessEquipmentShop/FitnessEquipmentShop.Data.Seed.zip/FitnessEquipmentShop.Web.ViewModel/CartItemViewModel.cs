﻿namespace FitnessEquipmentShop.Web.ViewModel
{
    public class CartItemViewModel
    {
        public int ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
